> **Suite v4 candidata.** Esiti precedenti conservati in `manual-feedback-v2.json` e `manual-feedback-v3.json`.
> La riapertura di questi nuovi file in MMS6/MMS10 resta da eseguire.

# Suite manuale Movie Magic — dati esclusivamente sintetici

Questi file NON sono certificati da Movie Magic. `manifest.json` riporta il
risultato dei parser di Stripboard Studio e i confronti automatici con il modello
corrente; apertura, salvataggio e riapertura in MMS6/MMS10 restano **DA ESEGUIRE**.
Non è stato usato il contenuto del demo Wonderful Life, né alcun progetto privato.
I dati sintetici sono distribuibili con la licenza MIT del repository.

## Riproduzione

Dalla directory del repository, con Node 24+, Chromium e Playwright disponibili:

```sh
python -m http.server 8766 --bind 127.0.0.1
# In un secondo terminale:
CHROME_PATH=/usr/bin/chromium node tests/generate-manual-suite.cjs
```

`STUDIO_URL` cambia l'URL del server; `STUDIO_MANUAL_OUTPUT` cambia la cartella
output. La suite sostituisce il generatore casuale SOLO nella pagina di test con
seed 271828: gli output e gli SHA-256 sono riproducibili. L'applicazione normale
continua a usare casualità crittografica. Il generatore rilegge ogni export con
`parseMsd` o `parseMmsx`, verifica assenza di mutazioni e confronta campi,
associazioni, quantità, calendari, ordine strip, date, proprietà, eventi e Red
Flags con il progetto di partenza e con le perdite dichiarate. Il log completo
è in `automatic-checks.json`. Rigenerare aggiorna `manual-results.csv`: conservare
una copia dei risultati manuali compilati fuori dalla cartella generata.

## Casi

| Prefisso | Origine e operazioni |
|---|---|
| 01 | Nuovo progetto vuoto, un piano e un calendario |
| 01b | Nuovo progetto con una scena nel Boneyard, ottavi assenti |
| 02 | Nuovo progetto complesso: scene, accenti, quantità assente/zero/3, proprietà strutturate, categoria personalizzata, due piani, banner, giornate, eccezioni di calendario, calendario non assegnato, evento con target elemento, Red Flag su tre date |
| 03 | Importazione MSD sintetico e modifica completa di scena/elemento; MSD e conversione MSD→MMSX |
| 04 | Importazione MMSX sintetico con due segmenti e Boneyard condiviso, opachi e numero oltre precisione JS; modifica scena, MMSX e conversione MMSX→MSD |
| 05–07 | Passaggi attraverso Studio v3 da progetto nuovo, MSD modificato e MMSX modificato; allegati anche i contenitori `.studio.json` |
| 08 | Nativi invariati, export identico byte per byte |
| 09 | Contenitori legacy Studio v1/v2 sintetici migrati a v3 e successivamente esportati |

Le varianti ricostruite sono EPSF `04.00.000` / MMB10, 11 sezioni per MMS6 e MMS2 `dataFormat: 5`
per MMS10. `MMS2` è la firma interna anche quando l'estensione è `.mmsx`.
MMSX 3 e 3 ibrido sono verificati separatamente nei test di conservazione nativa;
non vengono sintetizzati come nuova destinazione. Le proprietà opache rimangono
nell'archivio originale del file Studio; gli export ricostruiti ne dichiarano
l'omissione. Gli ID di scene MSD sono rigenerati come numeri; gli elementi sono
referenziati per categoria/nome. La variante MSD non ha quantità per associazione
verificate: zero e 3 diventano assenza, non valori aggiunti al nome.

## Checklist per ciascun file

- [ ] Registrare nome file, SHA-256 dal manifest, sistema operativo, data/tester
      e **versione completa/build** del programma in `manual-results.csv`.
- [ ] Aprire `.msd` in MMS6 o importare/aprire `.mmsx` in MMS10. Registrare errori,
      richieste di riparazione, avvisi e conversioni automatiche testualmente.
- [ ] Confrontare titolo, produzione, numero di scene, categorie ed elementi con
      `expected` nel manifest; verificare accenti in nomi, sinossi e commenti.
- [ ] Aprire le schede: confrontare scene/campi, ottavi assenti e zero, tempi,
      proprietà, categorie/elementi associati e quantità. In MSD verificare
      espressamente l'assenza delle quantità omesse, senza alterare il nome.
- [ ] Controllare tutti i piani e, in MMS10, tutti i segmenti: stesso ordine di
      scene e banner, stesse giornate e residui. Controllare Boneyard condiviso
      fra segmenti MMSX e copie separate dei piani MSD. I gruppi vuoti sono
      intenzionali. Il manifest elenca date e numeri aspettati per ogni piano.
- [ ] Verificare calendario assegnato, inizio produzione, pattern settimanale,
      festività 8 ottobre 2026 ed eccezione lavorativa 10 ottobre 2026 nei casi
      complessi. Verificare le date effettive delle giornate, non solo le etichette.
- [ ] Verificare eventi, target e intervalli in MMS10; l'assenza degli eventi in
      MSD è dichiarata. Verificare le Red Flags del 6–8 ottobre inclusi: tre entry
      MSD per intervallo oppure un intervallo MMSX, con nota e target corretti.
- [ ] Confrontare ogni voce `compatibility.omitted`/`transformed`: nessuna perdita
      aggiuntiva e nessuna relazione sospesa. I colori della griglia e delle scene sono verificati secondo le capacità dichiarate; i layout/report proprietari
      originali sono sostituiti da template sintetici. Registrare i default scelti
      dal programma, incluso il layout strip sintetico minimo MSD ed eventuali layout mancanti che impediscono l'uso.
- [ ] Salvare con un NUOVO nome nel formato nativo di Movie Magic; chiudere,
      riaprire la copia e ripetere i confronti. Conservare copia e schermate
      delle anomalie senza sostituire i file di questa suite.
- [ ] Per 05–07 aprire anche il `.studio.json` in Stripboard Studio, verificare
      modello corrente e riesportare, quindi ripetere l'apertura in Movie Magic.

## Registro delle prove ancora necessarie

Il CSV contiene una riga per ogni export, tutte inizialmente DA ESEGUIRE. Usare
PASS, FAIL o PARZIALE solo dopo aver svolto la prova; allegare riferimenti a
screenshot e copia risalvata nel campo anomalie. Per versioni diverse aggiungere
righe, senza sovrascrivere una prova precedente.

| Programma | Versione esatta/build | Sistema | File/caso | Apertura | Dati/relazioni | Risalvataggio e riapertura | Anomalie |
|---|---|---|---|---|---|---|---|
| MMS6 | da registrare | da registrare | tutti i `.msd` | DA ESEGUIRE | DA ESEGUIRE | DA ESEGUIRE | |
| MMS10 | da registrare | da registrare | tutti i `.mmsx` | DA ESEGUIRE | DA ESEGUIRE | DA ESEGUIRE | |

L'apertura storica di un diverso MSD modificato in MMS 6.02.413, citata nell'audit,
non vale come prova per questi contenitori nuovi. Restano da verificare requisiti
non documentati dei manager vuoti/default, compatibilità della build MMS10 con
format 5, gestione del Boneyard e comportamento del successivo salvataggio.

## Prova mirata di questa revisione

Prima provare 02 MMSX: colori strip/palette, evento visibile e cliccabile, pagina e report Red Flags, One-line Vertical e Calendar Report; poi 02 MSD: Day/Night e colori. Provare 01/01b anche su One-line Vertical senza scene programmate.
Il caso 01b non imposta INT/EXT e D/N: i campi vuoti sono intenzionali. Il file
10-diagnostic-int-ext-dn.msd li imposta esplicitamente. Gli altri controlli 10
isolano tempi, Unicode, proprietà, giornata vuota, Red Flag e secondo piano;
servono solo se il complesso viene ancora rifiutato. I metadati calendar dei
Boneyard non assegnano date alle loro strip. Gli inizi tecnici mancanti nei
contenitori MMSX sintetici usano 01/01/2000 per inizializzare la navigazione,
con trasformazione dichiarata nel manifest.


## Controlli aggiunti nella v4

- `11-redflag-*`: confrontare il report con quantità Èlia zero, assente e uno,
  con/senza eventi. `single-day` e `scheduled-range` usano quantità uno e nessun
  evento: isolano l'intervallo 6, 6–7 o 6–8 ottobre. La causa di NO RED FLAGS è
  ancora da dimostrare. Il caso principale 02 ora usa Èlia=1 e un oggetto=0.
- `12-event-native-none`: evento ordinario con colore esplicito, come il nuovo
  evento creato dall'utente. Confrontare con il fitting del caso 02, anche in DOOD.
- `13-color-losses`: override rosso RGB per una scena. In MMSX è previsto il
  token più vicino (#FA003F); in MSD il colore della griglia (#FCFA7C).
  Entrambe le differenze sono dichiarate nel manifest e confrontate automaticamente.
- In 04/07/08/09 le due sub-board dello stesso piano contengono scene diverse.
  Affiancarle e spostare una scena: nessun'altra istanza deve sparire. Lo stesso
  riferimento in piani padri alternativi è invece intenzionale.
- Verificare i colori dopo salvataggio/riapertura nativi, non solo all'apertura.
  I file del Boneyard devono restare privi di date delle strip.

Dettagli delle correzioni e delle incognite: `docs/native-regressions-v4.md` nel
repository. Le due ricostruzioni del file risalvato dall'utente sono distribuite
separatamente, con manifest delle perdite e confronto actor-0/actor-1 esplicito.
